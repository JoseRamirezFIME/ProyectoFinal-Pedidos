﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TestPedidos
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Datos.IdUsuario = Conexion.ConsultaEscalar("Select Id_Usuario from Usuario where Usuario='" + txbUsuario.Text + "' and Pass='" + txbPass.Text + "'");
            if (Datos.IdUsuario != "" )
            {
                Form Login = new Form1();
                this.Hide();
                Login.Show();
            }
            else
            {
                System.Windows.Forms.MessageBox.Show("Usuario o Contraseña Incorrectos.", "Program Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form Registro = new Registro();
            this.Hide();
            Registro.Show();
        }

        private void Login_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            Form CambiarPass = new CambiarPass();
            this.Hide();
            CambiarPass.Show();
        }
    }
}
