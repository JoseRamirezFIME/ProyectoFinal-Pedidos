﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TestPedidos
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

        }
        DataTable tabla = new DataTable("Tabla");


        private void Form1_Load(object sender, EventArgs e)
        {
            Conexion.LlenarCombo(comboBox1,"Nombre_Producto","Id_Producto");
           lbPedido.Text = Conexion.LlenarPedido().ToString();
            Conexion.tabla(tabla);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        { 
            label5.Text = Conexion.Precio((int)comboBox1.SelectedValue);
            
        }
        decimal total_f = new decimal();

        private void button1_Click(object sender, EventArgs e)
        {
            DateTime fecha;
            fecha = DateTime.Now;
            decimal total_p;
            total_p = Convert.ToDecimal(label5.Text) * Convert.ToInt32(txbCantidad.Text);
            Datos.Proveedor = Conexion.Proveedor((int)comboBox1.SelectedValue);
            Conexion.LlenarDataGrid(fecha.ToShortDateString(),total_p,Convert.ToInt32(txbCantidad.Text),Datos.Proveedor.Rows[0].ItemArray[0].ToString(), comboBox1.Text,dataGridView1);
            tabla.Rows.Add(Convert.ToInt32(lbPedido.Text),comboBox1.SelectedValue,Convert.ToInt32(Datos.IdUsuario),Convert.ToInt32(txbCantidad.Text), Datos.Proveedor.Rows[0].ItemArray[1].ToString(),total_p,fecha.ToShortDateString()); 
            total_f = total_p + total_f;
            label7.Text = "" + total_f;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Conexion.GuardarPedido(tabla);
           txbCantidad.Text = "";
            label7.Text = "";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string var;
            var = "Pedido" + lbPedido.Text;
            System.IO.StreamWriter file = new System.IO.StreamWriter(@"C:\Users\Usuario\OneDrive\Escritorio\Imagenes\" + var + ".csv");
            try
            {
                string sLine = "";

                for (int r = 0; r < dataGridView1.Rows.Count - 1; r++)
                {

                    for (int c = 0; c <= dataGridView1.Columns.Count - 1; c++)
                    {
                        sLine = sLine + dataGridView1.Rows[r].Cells[c].Value;
                        if (c != dataGridView1.Columns.Count - 1)
                        {

                            sLine = sLine + ",";
                        }
                    }

                    file.WriteLine(sLine);
                    sLine = "";
                }

                file.Close();
                System.Windows.Forms.MessageBox.Show("Exportado Correctamente.", "Program Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (System.Exception err)
            {
                System.Windows.Forms.MessageBox.Show(err.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                file.Close();
            }

            dataGridView1.Rows.Clear();
            tabla.Rows.Clear();
            txbCantidad.Text = "";
            label7.Text = "";
            lbPedido.Text = (Convert.ToInt32(lbPedido.Text) + 1).ToString();
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        
    }
}
