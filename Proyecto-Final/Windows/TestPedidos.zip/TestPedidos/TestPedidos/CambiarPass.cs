﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TestPedidos
{
    public partial class CambiarPass : Form
    {
        public CambiarPass()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int filasafectadas=0;
            if  (txbPass.Text == txbPassNueva.Text ){
                filasafectadas=Conexion.CambiarPass(txbCorreo.Text,txbPassNueva.Text);
                if (filasafectadas==0) {
                    MessageBox.Show("Correo no registrado");
                }
                else
                {
                    MessageBox.Show("Contraseña cambiada correctamente");

                }
            }
            else
            {
                MessageBox.Show("Las Contraseñas no Coinciden");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form Login = new Login();
            this.Hide();
            Login.Show();
        }
    }
}
