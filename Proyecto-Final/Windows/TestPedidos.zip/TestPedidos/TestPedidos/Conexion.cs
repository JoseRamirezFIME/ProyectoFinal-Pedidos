﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace TestPedidos
{
    class Conexion
    {
        static SqlConnection cnx;
        static string cadena = @"Server=localhost\SQLEXPRESS01;Database=Pedidos;Trusted_Connection=True;";

        private static void Conectar()
        {
            cnx = new SqlConnection(cadena);
            cnx.Open();
        }

        private static void Desconectar()
        {
            cnx.Close();
            cnx = null;
        }

        public static string ConsultaEscalar(string consulta)
        {
            Conectar();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(consulta, cnx);
            da.Fill(dt);
            if (dt.Rows.Count == 0)
            {
                Desconectar();

                return "";
            }
            Desconectar();
            return dt.Rows[0].ItemArray[0].ToString();
        }

        public static void CrearUsuario(string Usuario, string correo, string pass)
        {
            Conectar();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = cnx;
            cmd.CommandText = "Insert into Usuario(Usuario,Correo,Pass) values(@Usuario,@Correo,@Pass)";
            cmd.Parameters.Add("@Usuario", SqlDbType.VarChar);
            cmd.Parameters["@Usuario"].Value = Usuario;
            cmd.Parameters.Add("@Correo", SqlDbType.VarChar);
            cmd.Parameters["@Correo"].Value = correo;
            cmd.Parameters.Add("@Pass", SqlDbType.VarChar);
            cmd.Parameters["@Pass"].Value = pass;
            cmd.ExecuteNonQuery();
        }

        public static int CambiarPass(string correo, string pass)
        {
            int filasAfectadas = 0;

            Conectar();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = cnx;
            cmd.CommandText = "UPDATE Usuario SET Pass='" + pass + "' where Correo='" + correo + "'";
            filasAfectadas = cmd.ExecuteNonQuery();
            Desconectar();
            return filasAfectadas;
        }

        public static void LlenarCombo(ComboBox combo, string nombre, string id)
        {

            Conectar();
            combo.ValueMember = id;
            combo.DisplayMember = nombre;
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter("Select Id_Producto, Nombre_Producto from Producto", cnx);
            da.Fill(dt);
            combo.DataSource = dt;
        }

        public static string Precio(int Id)
        {
            Conectar();
            DataTable dt = new DataTable();
            string consulta;
            consulta = "Select Precio_Unitario from Producto where Id_Producto = " + Id;
            SqlDataAdapter da = new SqlDataAdapter(consulta, cnx);
            da.Fill(dt);
            Desconectar();
            return dt.Rows[0].ItemArray[0].ToString();

        }

        public static DataTable Proveedor(int id_Producto)
        {
            Conectar();
            DataTable dt = new DataTable();
            string consulta;
            consulta = "select prov.Nombre,prov.Id_Proveedor from Producto as prod,Proveedor as prov where prod.Id_Proveedor = prov.Id_Proveedor and prod.Id_Producto=" + id_Producto;
            SqlDataAdapter da = new SqlDataAdapter(consulta, cnx);
            da.Fill(dt);
            Desconectar();
            return dt;
        }

        public static void LlenarDataGrid(string fecha, decimal total, int cantidad, string Nombre_Proveedor,  string producto, DataGridView datagrid)
        {
            Conectar();
            datagrid.Rows.Add(producto, cantidad, Nombre_Proveedor, total, fecha);
        }
        public static void GuardarPedido(DataTable data)
        {   
            int pe;
            pe = LlenarPedido();
            for (int i = 0; i < data.Rows.Count; i++)
            {
                int producto, cantidad, proveedor;
                decimal total;
                DateTime fecha;
                producto = Convert.ToInt32(data.Rows[i].ItemArray[1]);
                cantidad = Convert.ToInt32(data.Rows[i].ItemArray[3]);
                proveedor = Convert.ToInt32(data.Rows[i].ItemArray[4]);
                total = Convert.ToDecimal(data.Rows[i].ItemArray[5]);
                fecha = Convert.ToDateTime(data.Rows[i].ItemArray[6]);
                Conectar();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = cnx;
                cmd.CommandText = "Insert into Pedido(Id_Pedido,Id_Producto,Id_Usuario,Cantidad,Id_Proveedor,Total,Fecha) values(@Id_Pedido,@Id_Producto,@Id_Usuario,@Cantidad,@Id_Proveedor,@Total,@Fecha)";
                cmd.Parameters.Add("@Id_Pedido", SqlDbType.Int);
                cmd.Parameters["@Id_Pedido"].Value = pe;

                cmd.Parameters.Add("@Id_Producto", SqlDbType.Int);
                cmd.Parameters["@Id_Producto"].Value= producto;

                cmd.Parameters.Add("@Id_Usuario", SqlDbType.Int);
                cmd.Parameters["@Id_Usuario"].Value=Convert.ToInt32(Datos.IdUsuario);

                cmd.Parameters.Add("@Cantidad", SqlDbType.Int);
                cmd.Parameters["@Cantidad"].Value = cantidad;

                cmd.Parameters.Add("@Id_Proveedor", SqlDbType.Int);
                cmd.Parameters["@Id_Proveedor"].Value = proveedor;

                cmd.Parameters.Add("@Total", SqlDbType.Decimal);
                cmd.Parameters["@Total"].Value=total;

                cmd.Parameters.Add("@Fecha", SqlDbType.Date);
                cmd.Parameters["@Fecha"].Value=fecha;
                cmd.ExecuteNonQuery();
            }
        }

        public static int LlenarPedido()
        {
            Conectar();
            DataTable dt = new DataTable();
            string consulta;
            consulta = "Select Id_Pedido from Pedido ";
            SqlDataAdapter da = new SqlDataAdapter(consulta, cnx);
            da.Fill(dt);
            if (dt.Rows.Count == 0)
                    {
                Desconectar();
                return 1;
            }
            Desconectar();
            return Convert.ToInt32(dt.Rows[dt.Rows.Count - 1].ItemArray[0]) + 1;
        }

        public static void tabla(DataTable pedido)
        {
            pedido.Columns.Add("Id_Pedido");
            pedido.Columns.Add("Id_Producto");
            pedido.Columns.Add("Id_Usuario");
            pedido.Columns.Add("Cantidad");
            pedido.Columns.Add("Id_Proveedor");
            pedido.Columns.Add("Total");
            pedido.Columns.Add("Fecha");

        }
    }
}
