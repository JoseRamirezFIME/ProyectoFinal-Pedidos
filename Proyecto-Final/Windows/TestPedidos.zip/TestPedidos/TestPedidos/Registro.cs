﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TestPedidos
{
    public partial class Registro : Form
    {
        public Registro()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form Login = new Login();
            this.Hide();
            Login.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
             if (txbUsuario.Text != "" & txbCorreo.Text!="" & txbPass.Text != "")
            {
                Conexion.CrearUsuario(txbUsuario.Text,txbCorreo.Text,txbPass.Text);
                MessageBox.Show("Registrado Correctamente");
                Form Login = new Login();
                this.Hide();
                Login.Show();
            }
            else
            {
                MessageBox.Show("Favor de llenar todos los campos");
            }
            
        }

        private void Registro_FormClosed(object sender, FormClosedEventArgs e)
        {
            Form Login = new Login();
            this.Hide();
            Login.Show();
        }
    }
}
